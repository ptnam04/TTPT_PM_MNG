<?php
class DefaultController
{
    public function index()
    {
        echo "HELLO HUTECH ";
    }
}