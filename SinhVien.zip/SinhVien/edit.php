<?php
include 'db.php';
$err = '';
if (!isset($_GET['MaSV'])) {
    header('Location: index.php');
    exit();
}
$ma = $_GET['MaSV'];
// Lấy thông tin sinh viên cũ
$stmt = $conn->prepare("SELECT * FROM SinhVien WHERE MaSV = ?");
$stmt->bind_param("s", $ma);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    echo '<div class="alert alert-danger">Không tìm thấy sinh viên!</div>';
    exit();
}
$sv = $result->fetch_assoc();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ten = trim($_POST['HoTen']);
    $gt = trim($_POST['GioiTinh']);
    $ns = $_POST['NgaySinh'];
    $hinh = trim($_POST['Hinh']);
    $mn = $_POST['MaNganh'];
    if ($ten && $gt && $ns && $hinh && $mn) {
        $sql = "UPDATE SinhVien SET HoTen=?, GioiTinh=?, NgaySinh=?, Hinh=?, MaNganh=? WHERE MaSV=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $ten, $gt, $ns, $hinh, $mn, $ma);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit();
        } else {
            $err = "Lỗi: " . $conn->error;
        }
    } else {
        $err = "Vui lòng nhập đầy đủ thông tin!";
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa Sinh Viên</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h2>Sửa Sinh Viên</h2>
    <?php if ($err): ?>
        <div class="alert alert-danger"><?= $err ?></div>
    <?php endif; ?>
    <form method="post" class="row g-3">
        <div class="col-md-6">
            <label class="form-label">Mã SV</label>
            <input name="MaSV" class="form-control" value="<?= htmlspecialchars($sv['MaSV']) ?>" readonly>
        </div>
        <div class="col-md-6">
            <label class="form-label">Họ tên</label>
            <input name="HoTen" class="form-control" value="<?= htmlspecialchars($sv['HoTen']) ?>" required>
        </div>
        <div class="col-md-4">
            <label class="form-label">Giới tính</label>
            <select name="GioiTinh" class="form-select" required>
                <option value="Nam" <?= $sv['GioiTinh']=='Nam'?'selected':'' ?>>Nam</option>
                <option value="Nữ" <?= $sv['GioiTinh']=='Nữ'?'selected':'' ?>>Nữ</option>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">Ngày sinh</label>
            <input name="NgaySinh" type="date" class="form-control" value="<?= $sv['NgaySinh'] ?>" required>
        </div>
        <div class="col-md-4">
            <label class="form-label">Hình (đường dẫn)</label>
            <input name="Hinh" class="form-control" value="<?= htmlspecialchars($sv['Hinh']) ?>" required>
        </div>
        <div class="col-md-6">
            <label class="form-label">Ngành</label>
            <select name="MaNganh" class="form-select" required>
                <?php
                $res = $conn->query("SELECT * FROM NganhHoc");
                while ($r = $res->fetch_assoc()) {
                    $selected = $sv['MaNganh'] == $r['MaNganh'] ? 'selected' : '';
                    echo "<option value='{$r['MaNganh']}' $selected>{$r['TenNganh']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-success">Cập nhật</button>
            <a href="index.php" class="btn btn-secondary">Quay lại</a>
        </div>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
