<?php
session_start();
include 'db.php';
if (!isset($_SESSION['MaSV'])) {
    header('Location: login.php');
    exit();
}
$ma_sv = $_SESSION['MaSV'];
// Lấy thông tin sinh viên
$stmt_sv = $conn->prepare("SELECT sv.MaSV, sv.HoTen, sv.GioiTinh, sv.NgaySinh, nh.TenNganh FROM SinhVien sv JOIN NganhHoc nh ON sv.MaNganh = nh.MaNganh WHERE sv.MaSV = ?");
$stmt_sv->bind_param("s", $ma_sv);
$stmt_sv->execute();
$sinh_vien = $stmt_sv->get_result()->fetch_assoc();
if (!$sinh_vien) {
    // Trường hợp không tìm thấy sinh viên, có thể do dữ liệu không khớp hoặc tài khoản lỗi
    session_unset();
    session_destroy();
    header('Location: login.php?error=svnotfound');
    exit();
}
$current_date_display = date('d/m/Y');
$thongbao = '';
// Xử lý nút Xác Nhận và lưu vào database
if (isset($_GET['action']) && $_GET['action'] == 'confirm_register' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_SESSION['cart_courses']) && !empty($_SESSION['cart_courses'])) {
        $conn->begin_transaction();
        try {
            // 1. Tạo bản ghi DangKy
            $ngaydangky_db = date('Y-m-d');
            $stmt_dk = $conn->prepare("INSERT INTO DangKy (NgayDK, MaSV) VALUES (?, ?)");
            $stmt_dk->bind_param("ss", $ngaydangky_db, $ma_sv);
            if (!$stmt_dk->execute()) {
                throw new Exception("Lỗi khi tạo bản ghi đăng ký: " . $stmt_dk->error);
            }
            $madk = $conn->insert_id;
            // 2. Thêm từng học phần vào ChiTietDangKy
            $stmt_ctdk = $conn->prepare("INSERT INTO ChiTietDangKy (MaDK, MaHP) VALUES (?, ?)");
            foreach ($_SESSION['cart_courses'] as $course) {
                $mahp_to_insert = $course['MaHP'];
                $stmt_ctdk->bind_param("is", $madk, $mahp_to_insert);
                if (!$stmt_ctdk->execute()) {
                    throw new Exception("Lỗi khi thêm chi tiết học phần {$mahp_to_insert}: " . $stmt_ctdk->error);
                }
            }
            $conn->commit();
            $_SESSION['cart_courses'] = []; // Xóa giỏ hàng sau khi xác nhận
            $thongbao = '<div class="alert alert-success">Đăng ký học phần thành công!</div>';
        } catch (Exception $e) {
            $conn->rollback();
            $thongbao = '<div class="alert alert-danger">Lỗi xác nhận đăng ký: ' . $e->getMessage() . '</div>';
        }
    } else {
        $thongbao = '<div class="alert alert-warning">Giỏ hàng trống, không có gì để xác nhận!</div>';
    }
}
// Xử lý xóa học phần riêng lẻ khỏi session
if (isset($_GET['action']) && $_GET['action'] == 'delete_hp' && isset($_GET['MaHP'])) {
    $mahp_to_delete = $_GET['MaHP'];
    if (isset($_SESSION['cart_courses'])) {
        foreach ($_SESSION['cart_courses'] as $key => $item) {
            if ($item['MaHP'] == $mahp_to_delete) {
                unset($_SESSION['cart_courses'][$key]);
                // Reset keys for array_values to re-index array
                $_SESSION['cart_courses'] = array_values($_SESSION['cart_courses']);
                break;
            }
        }
    }
    header('Location: dangki_hocphan.php');
    exit();
}
// Xử lý xóa toàn bộ giỏ hàng khỏi session
if (isset($_GET['action']) && $_GET['action'] == 'clear_all') {
    $_SESSION['cart_courses'] = [];
    header('Location: dangki_hocphan.php');
    exit();
}
// Tính toán số lượng và tổng tín chỉ từ giỏ hàng session
$num_courses = 0;
$total_credits = 0;
$display_courses = [];
if (isset($_SESSION['cart_courses'])) {
    $display_courses = $_SESSION['cart_courses'];
    foreach ($display_courses as $course) {
        $num_courses++;
        $total_credits += $course['SoTinChi'];
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng Kí Học Phần</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .summary-info { color: red; font-weight: bold; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Test1</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="index.php">Sinh Viên</a></li>
        <li class="nav-item"><a class="nav-link" href="hocphan.php">Học Phần</a></li>
        <li class="nav-item"><a class="nav-link active" href="dangki_hocphan.php">Đăng Kí (<?= $num_courses ?>)</a></li>
        <li class="nav-item">
          <?php if (isset($_SESSION['MaSV'])): ?>
            <a class="nav-link" href="logout.php">Đăng Xuất</a>
          <?php else: ?>
            <a class="nav-link" href="login.php">Đăng Nhập</a>
          <?php endif; ?>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-4">
    <h2 class="mb-3">Đăng Kí Học Phần</h2>
    <?= $thongbao ?>
    <table class="table table-bordered align-middle">
        <thead class="table-light">
            <tr>
                <th>MaHP</th>
                <th>Tên Học Phần</th>
                <th>Số Tín Chỉ</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php if ($num_courses > 0): ?>
            <?php foreach ($display_courses as $key => $row): ?>
                <tr>
                    <td><?= htmlspecialchars($row['MaHP']) ?></td>
                    <td><?= htmlspecialchars($row['TenHP']) ?></td>
                    <td><?= htmlspecialchars($row['SoTinChi']) ?></td>
                    <td>
                        <a href="dangki_hocphan.php?action=delete_hp&MaHP=<?= htmlspecialchars($row['MaHP']) ?>" class="link-primary" onclick="return confirm('Xóa học phần này khỏi giỏ hàng?')">Xóa</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="4" class="text-center">Chưa có học phần nào trong giỏ hàng.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
    <p class="summary-info">Số học phần: <?= $num_courses ?></p>
    <p class="summary-info">Tổng số tín chỉ: <?= $total_credits ?></p>
    <div class="text-center mt-5">
        <h4>Thông tin Đăng kí</h4>
        <p><strong>Mã số sinh viên:</strong> <?= htmlspecialchars($sinh_vien['MaSV']) ?></p>
        <p><strong>Họ tên Sinh viên:</strong> <?= htmlspecialchars($sinh_vien['HoTen']) ?></p>
        <p><strong>Ngày Sinh:</strong> <?= date('d/m/Y', strtotime($sinh_vien['NgaySinh'])) ?></p>
        <p><strong>Ngành Học:</strong> <?= htmlspecialchars($sinh_vien['TenNganh']) ?></p>
        <p><strong>Ngày Đăng Kí:</strong> <?= $current_date_display ?></p>
        <form method="post" action="dangki_hocphan.php?action=confirm_register">
            <button type="submit" class="btn btn-success" <?= $num_courses == 0 ? 'disabled' : '' ?>>Xác Nhận</button>
        </form>
    </div>
    <div class="text-center mt-3">
        <a href="dangki_hocphan.php?action=clear_all" class="btn btn-link" onclick="return confirm('Xóa toàn bộ đăng ký học phần trong giỏ hàng?')">Xóa Giỏ Hàng</a>
        <a href="hocphan.php" class="btn btn-link">Trở về giỏ hàng</a>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 