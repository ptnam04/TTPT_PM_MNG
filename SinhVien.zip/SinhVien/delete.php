<?php
include 'db.php';
if (!isset($_GET['MaSV'])) {
    header('Location: index.php');
    exit();
}
$ma = $_GET['MaSV'];
$conn->begin_transaction();
try {
    // 1. Lấy tất cả MaDK liên quan đến sinh viên này
    $dk_stmt = $conn->prepare("SELECT MaDK FROM DangKy WHERE MaSV = ?");
    $dk_stmt->bind_param("s", $ma);
    $dk_stmt->execute();
    $dks_result = $dk_stmt->get_result();
    while ($dk_row = $dks_result->fetch_assoc()) {
        $current_madk = $dk_row['MaDK'];
        // 2. Xóa các bản ghi trong ChiTietDangKy
        $delete_ctdk_stmt = $conn->prepare("DELETE FROM ChiTietDangKy WHERE MaDK = ?");
        $delete_ctdk_stmt->bind_param("i", $current_madk);
        if (!$delete_ctdk_stmt->execute()) {
            throw new Exception("Lỗi khi xóa chi tiết đăng ký cho MaDK {$current_madk}: " . $delete_ctdk_stmt->error);
        }
        // 3. Xóa các bản ghi trong DangKy
        $delete_dk_stmt = $conn->prepare("DELETE FROM DangKy WHERE MaDK = ?");
        $delete_dk_stmt->bind_param("i", $current_madk);
        if (!$delete_dk_stmt->execute()) {
            throw new Exception("Lỗi khi xóa đăng ký cho MaDK {$current_madk}: " . $delete_dk_stmt->error);
        }
    }
    // 4. Xóa sinh viên
    $delete_sv_stmt = $conn->prepare("DELETE FROM SinhVien WHERE MaSV = ?");
    $delete_sv_stmt->bind_param("s", $ma);
    if (!$delete_sv_stmt->execute()) {
        throw new Exception("Lỗi khi xóa sinh viên: " . $delete_sv_stmt->error);
    }
    $conn->commit();
    header('Location: index.php');
    exit();
} catch (Exception $e) {
    $conn->rollback();
    echo '<div class="alert alert-danger">Lỗi xóa sinh viên: ' . $e->getMessage() . '</div>';
    echo '<a href="index.php" class="btn btn-secondary">Quay lại</a>';
}
?>
