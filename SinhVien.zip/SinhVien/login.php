<?php
session_start();
include 'db.php';
// Nếu đã đăng nhập, chuyển hướng về trang chủ
if (isset($_SESSION['MaSV'])) {
    header('Location: index.php');
    exit();
}
$err = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ma = trim($_POST['username']);
    $pw = trim($_POST['password']);
    $stmt = $conn->prepare("SELECT * FROM SinhVien WHERE MaSV = ? AND Password = ?");
    $stmt->bind_param("ss", $ma, $pw);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $_SESSION['MaSV'] = $ma;
        header('Location: index.php');
        exit();
    } else {
        $err = 'Sai mã sinh viên hoặc mật khẩu!';
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background: #f4f4f4; }
        .login-box {
            max-width: 400px;
            margin: 60px auto;
            background: #fff;
            padding: 30px 30px 20px 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.08);
        }
    </style>
</head>
<body>
<div class="login-box">
    <h3 class="text-center mb-4">Login</h3>
    <?php if ($err): ?>
        <div class="alert alert-danger"><?= $err ?></div>
    <?php endif; ?>
    <form method="post">
        <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" placeholder="Username" required autofocus>
        </div>
        <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 