<?php
include 'db.php';
if (!isset($_GET['MaSV'])) {
    header('Location: index.php');
    exit();
}
$ma = $_GET['MaSV'];
$stmt = $conn->prepare("SELECT sv.*, nh.TenNganh FROM SinhVien sv JOIN NganhHoc nh ON sv.MaNganh = nh.MaNganh WHERE MaSV = ?");
$stmt->bind_param("s", $ma);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    echo '<div class="alert alert-danger">Không tìm thấy sinh viên!</div>';
    exit();
}
$sv = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Chi tiết Sinh Viên</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .student-img { width: 180px; height: auto; object-fit: cover; }
    </style>
</head>
<body>
<div class="container mt-4">
    <h2>Chi tiết Sinh Viên</h2>
    <div class="row">
        <div class="col-md-4">
            <img src="<?= htmlspecialchars($sv['Hinh']) ?>" class="student-img img-thumbnail mb-3">
        </div>
        <div class="col-md-8">
            <table class="table table-bordered">
                <tr><th>Mã SV</th><td><?= htmlspecialchars($sv['MaSV']) ?></td></tr>
                <tr><th>Họ tên</th><td><?= htmlspecialchars($sv['HoTen']) ?></td></tr>
                <tr><th>Giới tính</th><td><?= htmlspecialchars($sv['GioiTinh']) ?></td></tr>
                <tr><th>Ngày sinh</th><td><?= date('d/m/Y', strtotime($sv['NgaySinh'])) ?></td></tr>
                <tr><th>Ngành</th><td><?= htmlspecialchars($sv['TenNganh']) ?></td></tr>
                <tr><th>Hình</th><td><?= htmlspecialchars($sv['Hinh']) ?></td></tr>
            </table>
            <a href="index.php" class="btn btn-secondary">Quay lại</a>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
