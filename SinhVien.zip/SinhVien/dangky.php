<?php
session_start();
include 'db.php';
if (!isset($_SESSION['MaSV'])) {
    header('Location: login.php');
    exit();
}
$thongbao = '';
if (!isset($_GET['MaHP'])) {
    header('Location: hocphan.php');
    exit();
}
$mahp = $_GET['MaHP'];
// Lấy thông tin học phần để thêm vào giỏ hàng session
$stmt = $conn->prepare("SELECT * FROM HocPhan WHERE MaHP = ?");
$stmt->bind_param("s", $mahp);
$stmt->execute();
$hp = $stmt->get_result()->fetch_assoc();
if (!$hp) {
    echo '<div class="alert alert-danger">Không tìm thấy học phần!</div>';
    exit();
}
// Lấy danh sách sinh viên (không cần ở đây nữa vì đã đăng nhập)
// $svs = $conn->query("SELECT * FROM SinhVien");
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Bỏ qua phần chọn sinh viên vì đã biết sinh viên nào đang đăng nhập
    // $masv = $_POST['MaSV'];

    // Thêm học phần vào giỏ hàng session
    if (!isset($_SESSION['cart_courses'])) {
        $_SESSION['cart_courses'] = [];
    }
    // Tránh trùng lặp học phần trong giỏ hàng
    $already_in_cart = false;
    foreach ($_SESSION['cart_courses'] as $item) {
        if ($item['MaHP'] == $mahp) {
            $already_in_cart = true;
            break;
        }
    }
    if (!$already_in_cart) {
        $_SESSION['cart_courses'][] = [
            'MaHP' => $hp['MaHP'],
            'TenHP' => $hp['TenHP'],
            'SoTinChi' => $hp['SoTinChi']
        ];
    }
    
    // Chuyển hướng về trang giỏ hàng (dangki_hocphan.php)
    header('Location: dangki_hocphan.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng ký học phần</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Test1</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="index.php">Sinh Viên</a></li>
        <li class="nav-item"><a class="nav-link" href="hocphan.php">Học Phần</a></li>
        <li class="nav-item"><a class="nav-link active" href="dangki_hocphan.php">Đăng Kí</a></li>
        <li class="nav-item">
          <?php if (isset($_SESSION['MaSV'])): ?>
            <a class="nav-link" href="logout.php">Đăng Xuất</a>
          <?php else: ?>
            <a class="nav-link" href="login.php">Đăng Nhập</a>
          <?php endif; ?>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-4">
    <h2>Đăng ký học phần</h2>
    <div class="alert alert-info">Bạn đang thêm học phần '<?= htmlspecialchars($hp['TenHP']) ?>' vào giỏ hàng.</div>
    <p>Nhấn vào nút bên dưới để xác nhận thêm vào giỏ hàng của bạn.</p>
    <form method="post">
        <button type="submit" class="btn btn-success">Thêm vào giỏ hàng</button>
        <a href="hocphan.php" class="btn btn-secondary">Quay lại</a>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 