<?php include 'db.php';
$err = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ma = trim($_POST['MaSV']);
    $ten = trim($_POST['HoTen']);
    $gt = trim($_POST['GioiTinh']);
    $ns = $_POST['NgaySinh'];
    $hinh = trim($_POST['Hinh']);
    $mn = $_POST['MaNganh'];
    $password = ''; // Mặc định mật khẩu rỗng khi tạo mới

    if ($ma && $ten && $gt && $ns && $hinh && $mn) {
        // Kiểm tra MaSV đã tồn tại chưa
        $check_stmt = $conn->prepare("SELECT MaSV FROM SinhVien WHERE MaSV = ?");
        $check_stmt->bind_param("s", $ma);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        if ($check_result->num_rows > 0) {
            $err = "Lỗi: Mã sinh viên đã tồn tại!";
        } else {
            $sql = "INSERT INTO SinhVien VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssss", $ma, $ten, $gt, $ns, $hinh, $mn, $password);
            if ($stmt->execute()) {
                header("Location: index.php");
                exit();
            } else {
                $err = "Lỗi khi thêm sinh viên: " . $conn->error;
            }
        }
    } else {
        $err = "Vui lòng nhập đầy đủ thông tin!";
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm Sinh Viên</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h2>Thêm Sinh Viên</h2>
    <?php if ($err): ?>
        <div class="alert alert-danger"><?= $err ?></div>
    <?php endif; ?>
    <form method="post" class="row g-3">
        <div class="col-md-6">
            <label class="form-label">Mã SV</label>
            <input name="MaSV" class="form-control" required>
        </div>
        <div class="col-md-6">
            <label class="form-label">Họ tên</label>
            <input name="HoTen" class="form-control" required>
        </div>
        <div class="col-md-4">
            <label class="form-label">Giới tính</label>
            <select name="GioiTinh" class="form-select" required>
                <option value="Nam">Nam</option>
                <option value="Nữ">Nữ</option>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">Ngày sinh</label>
            <input name="NgaySinh" type="date" class="form-control" required>
        </div>
        <div class="col-md-4">
            <label class="form-label">Hình (đường dẫn)</label>
            <input name="Hinh" class="form-control" required>
        </div>
        <div class="col-md-6">
            <label class="form-label">Ngành</label>
            <select name="MaNganh" class="form-select" required>
                <?php
                $res = $conn->query("SELECT * FROM NganhHoc");
                while ($r = $res->fetch_assoc()) {
                    echo "<option value='{$r['MaNganh']}'>{$r['TenNganh']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-success">Lưu</button>
            <a href="index.php" class="btn btn-secondary">Quay lại</a>
        </div>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
