<?php
session_start();
include 'db.php';
if (!isset($_SESSION['MaSV'])) {
    header('Location: login.php');
    exit();
}
$ma_sv = $_SESSION['MaSV'];
// Lấy thông tin học phần đã đăng ký từ database
$sql = "SELECT HP.MaHP, HP.TenHP, HP.SoTinChi, DK.MaDK ";
$sql .= "FROM SinhVien SV ";
$sql .= "JOIN DangKy DK ON SV.MaSV = DK.MaSV ";
$sql .= "JOIN ChiTietDangKy CTDK ON DK.MaDK = CTDK.MaDK ";
$sql .= "JOIN HocPhan HP ON CTDK.MaHP = HP.MaHP ";
$sql .= "WHERE SV.MaSV = ?";
$stmt_registered = $conn->prepare($sql);
$stmt_registered->bind_param("s", $ma_sv);
$stmt_registered->execute();
$registered_courses = $stmt_registered->get_result();
$num_courses_registered = 0;
$total_credits_registered = 0;
$display_registered_courses = [];
while ($row = $registered_courses->fetch_assoc()) {
    $display_registered_courses[] = $row;
    $num_courses_registered++;
    $total_credits_registered += $row['SoTinChi'];
}
// Xử lý hủy đăng ký học phần (từ database)
if (isset($_GET['action']) && $_GET['action'] == 'delete_registered_hp' && isset($_GET['MaDK']) && isset($_GET['MaHP'])) {
    $madk_to_delete = $_GET['MaDK'];
    $mahp_to_delete = $_GET['MaHP'];
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("DELETE FROM ChiTietDangKy WHERE MaDK = ? AND MaHP = ?");
        $stmt->bind_param("is", $madk_to_delete, $mahp_to_delete);
        if (!$stmt->execute()) {
            throw new Exception("Lỗi khi xóa chi tiết đăng ký: " . $stmt->error);
        }
        // Kiểm tra nếu MaDK không còn ChiTietDangKy nào, thì xóa cả DangKy đó
        $check_stmt = $conn->prepare("SELECT COUNT(*) FROM ChiTietDangKy WHERE MaDK = ?");
        $check_stmt->bind_param("i", $madk_to_delete);
        $check_stmt->execute();
        $count = $check_stmt->get_result()->fetch_row()[0];
        if ($count == 0) {
            $delete_dk_stmt = $conn->prepare("DELETE FROM DangKy WHERE MaDK = ?");
            $delete_dk_stmt->bind_param("i", $madk_to_delete);
            if (!$delete_dk_stmt->execute()) {
                throw new Exception("Lỗi khi xóa bản ghi đăng ký: " . $delete_dk_stmt->error);
            }
        }
        $conn->commit();
        header('Location: registered_courses.php');
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        echo '<div class="alert alert-danger">Lỗi: ' . $e->getMessage() . '</div>';
    }
}
// Xử lý xóa toàn bộ đăng ký (từ database)
if (isset($_GET['action']) && $_GET['action'] == 'clear_all_registered') {
    $conn->begin_transaction();
    try {
        // Lấy tất cả MaDK của sinh viên này
        $dk_stmt = $conn->prepare("SELECT MaDK FROM DangKy WHERE MaSV = ?");
        $dk_stmt->bind_param("s", $ma_sv);
        $dk_stmt->execute();
        $dks_result = $dk_stmt->get_result();
        while ($row = $dks_result->fetch_assoc()) {
            $current_madk = $row['MaDK'];
            // Xóa ChiTietDangKy trước
            $delete_ctdk_stmt = $conn->prepare("DELETE FROM ChiTietDangKy WHERE MaDK = ?");
            $delete_ctdk_stmt->bind_param("i", $current_madk);
            if (!$delete_ctdk_stmt->execute()) {
                throw new Exception("Lỗi khi xóa chi tiết đăng ký: " . $delete_ctdk_stmt->error);
            }
            // Xóa DangKy
            $delete_dk_stmt = $conn->prepare("DELETE FROM DangKy WHERE MaDK = ?");
            $delete_dk_stmt->bind_param("i", $current_madk);
            if (!$delete_dk_stmt->execute()) {
                throw new Exception("Lỗi khi xóa bản ghi đăng ký chính: " . $delete_dk_stmt->error);
            }
        }
        $conn->commit();
        header('Location: registered_courses.php');
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        echo '<div class="alert alert-danger">Lỗi: ' . $e->getMessage() . '</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Học Phần Đã Đăng Kí</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .summary-info { color: red; font-weight: bold; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Test1</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="index.php">Sinh Viên</a></li>
        <li class="nav-item"><a class="nav-link" href="hocphan.php">Học Phần</a></li>
        <li class="nav-item"><a class="nav-link active" href="registered_courses.php">Đăng Kí (<?= $num_courses_registered ?>)</a></li>
        <li class="nav-item">
          <?php if (isset($_SESSION['MaSV'])): ?>
            <a class="nav-link" href="logout.php">Đăng Xuất</a>
          <?php else: ?>
            <a class="nav-link" href="login.php">Đăng Nhập</a>
          <?php endif; ?>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-4">
    <h2 class="mb-3">Học Phần Đã Đăng Kí</h2>
    <table class="table table-bordered align-middle">
        <thead class="table-light">
            <tr>
                <th>MaHP</th>
                <th>Tên Học Phần</th>
                <th>Số Tín Chỉ</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php if ($num_courses_registered > 0): ?>
            <?php foreach ($display_registered_courses as $row): ?>
                <tr>
                    <td><?= htmlspecialchars($row['MaHP']) ?></td>
                    <td><?= htmlspecialchars($row['TenHP']) ?></td>
                    <td><?= htmlspecialchars($row['SoTinChi']) ?></td>
                    <td>
                        <a href="registered_courses.php?action=delete_registered_hp&MaDK=<?= $row['MaDK'] ?>&MaHP=<?= $row['MaHP'] ?>" class="link-primary" onclick="return confirm('Hủy đăng ký học phần này?')">Hủy</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="4" class="text-center">Chưa có học phần nào được đăng ký.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
    <p class="summary-info">Số học phần: <?= $num_courses_registered ?></p>
    <p class="summary-info">Tổng số tín chỉ: <?= $total_credits_registered ?></p>
    <div class="text-end mt-3">
        <a href="registered_courses.php?action=clear_all_registered" class="btn btn-danger me-2" onclick="return confirm('Xóa toàn bộ học phần đã đăng ký?')">Hủy Tất Cả Đăng Ký</a>
        <a href="hocphan.php" class="btn btn-secondary">Đăng Ký Thêm Học Phần</a>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 