<?php
session_start();
include 'db.php';
// Phân trang
$limit = 10; // Hiển thị tất cả học phần trên 1 trang như hình mẫu
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;
// Đếm tổng số học phần
$total_sql = "SELECT COUNT(*) as total FROM HocPhan";
$total_result = $conn->query($total_sql);
$total_row = $total_result->fetch_assoc();
$total_hp = $total_row['total'];
$total_pages = ceil($total_hp / $limit);
// Lấy dữ liệu học phần cho trang hiện tại
$sql = "SELECT * FROM HocPhan LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Danh sách Học Phần</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Test1</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="index.php">Sinh Viên</a></li>
        <li class="nav-item"><a class="nav-link active" href="hocphan.php">Học Phần</a></li>
        <li class="nav-item"><a class="nav-link" href="hocphan.php">Đăng Kí</a></li>
        <li class="nav-item">
          <?php if (isset($_SESSION['MaSV'])): ?>
            <a class="nav-link" href="logout.php">Đăng Xuất</a>
          <?php else: ?>
            <a class="nav-link" href="login.php">Đăng Nhập</a>
          <?php endif; ?>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-4">
    <h2 class="mb-3">DANH SÁCH HỌC PHẦN</h2>
    <table class="table table-bordered align-middle">
        <thead class="table-light">
            <tr>
                <th>Mã Học Phần</th>
                <th>Tên Học Phần</th>
                <th>Số Tín Chỉ</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['MaHP']) ?></td>
                <td><?= htmlspecialchars($row['TenHP']) ?></td>
                <td><?= htmlspecialchars($row['SoTinChi']) ?></td>
                <td>
                    <a href="dangky.php?MaHP=<?= htmlspecialchars($row['MaHP']) ?>" class="btn btn-success">Đăng Kí</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 