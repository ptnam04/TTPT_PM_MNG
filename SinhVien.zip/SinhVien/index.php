<?php include('db.php'); ?>
<?php
session_start();
// Phân trang
$limit = 4;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;
// Đếm tổng số sinh viên
$total_sql = "SELECT COUNT(*) as total FROM SinhVien";
$total_result = $conn->query($total_sql);
$total_row = $total_result->fetch_assoc();
$total_students = $total_row['total'];
$total_pages = ceil($total_students / $limit);
// Lấy dữ liệu sinh viên cho trang hiện tại
$sql = "SELECT sv.*, nh.TenNganh FROM SinhVien sv JOIN NganhHoc nh ON sv.MaNganh = nh.MaNganh LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Trang Sinh Viên</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .student-img { width: 100px; height: auto; object-fit: cover; }
        .navbar-brand { font-weight: bold; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Test1</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link active" href="index.php">Sinh Viên</a></li>
        <li class="nav-item"><a class="nav-link" href="hocphan.php">Học Phần</a></li>
        <li class="nav-item"><a class="nav-link" href="registered_courses.php">Đăng Kí</a></li>
        <li class="nav-item">
          <?php if (isset($_SESSION['MaSV'])): ?>
            <a class="nav-link" href="logout.php">Đăng Xuất</a>
          <?php else: ?>
            <a class="nav-link" href="login.php">Đăng Nhập</a>
          <?php endif; ?>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-4">
    <h2>TRANG SINH VIÊN</h2>
    <a href="create.php" class="btn btn-primary mb-3">Add Student</a>
    <table class="table table-bordered align-middle">
        <thead class="table-light">
            <tr>
                <th>MaSV</th>
                <th>HoTen</th>
                <th>GioiTinh</th>
                <th>NgaySinh</th>
                <th>Hinh</th>
                <th>MaNganh</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['MaSV']) ?></td>
                <td><?= htmlspecialchars($row['HoTen']) ?></td>
                <td><?= htmlspecialchars($row['GioiTinh']) ?></td>
                <td><?= date('d/m/Y', strtotime($row['NgaySinh'])) ?></td>
                <td><img src="<?= htmlspecialchars($row['Hinh']) ?>" class="student-img"></td>
                <td><?= htmlspecialchars($row['TenNganh']) ?></td>
                <td>
                    <a href="detail.php?MaSV=<?= urlencode($row['MaSV']) ?>">Chi tiết</a> | 
                    <a href="edit.php?MaSV=<?= urlencode($row['MaSV']) ?>">Sửa</a> | 
                    <a href="delete.php?MaSV=<?= urlencode($row['MaSV']) ?>" onclick="return confirm('Xoá sinh viên này?')">Xoá</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    <!-- Phân trang -->
    <nav>
      <ul class="pagination">
        <li class="page-item<?= $page <= 1 ? ' disabled' : '' ?>">
          <a class="page-link" href="?page=<?= $page-1 ?>">Previous</a>
        </li>
        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
          <li class="page-item<?= $i == $page ? ' active' : '' ?>">
            <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
          </li>
        <?php endfor; ?>
        <li class="page-item<?= $page >= $total_pages ? ' disabled' : '' ?>">
          <a class="page-link" href="?page=<?= $page+1 ?>">Next</a>
        </li>
      </ul>
    </nav>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

